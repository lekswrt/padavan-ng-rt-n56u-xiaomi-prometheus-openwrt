#!/bin/bash
# Цвета:
RED='\033[1;31m'
GREEN='\033[1;32m'
BLUE='\033[1;36m'
YELLOW='\033[1;33m'
NONE='\033[0m'
RED0='\033[0;31m'
GREEN0='\033[0;32m'
#========================
cd ./$ICP
git config core.abbrev 7
cd ..
echo -e "$BLUE GIT FIX$GREEN OK$NONE"
sleep 1
